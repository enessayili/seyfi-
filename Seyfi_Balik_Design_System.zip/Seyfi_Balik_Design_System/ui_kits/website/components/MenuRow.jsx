// A single text-row in the long menu (no photo).
const MenuRow = ({ name, desc, price, special }) => (
  <div style={{
    display: 'grid', gridTemplateColumns: '1fr auto', gap: 32,
    padding: '20px 0', borderBottom: '1px solid rgba(10,31,74,0.10)',
    alignItems: 'baseline',
  }}>
    <div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
        <h4 style={{
          fontFamily: 'Cherston, "Big Shoulders Display", sans-serif',
          fontWeight: 700, fontSize: 22, lineHeight: 1.1,
          letterSpacing: '0.005em', textTransform: 'uppercase',
          color: '#0a1f4a', margin: 0,
        }}>{name}</h4>
        {special && (
          <span style={{
            fontFamily: 'Sacramento, Caveat, cursive', fontWeight: 700,
            fontSize: 22, color: '#16489f', lineHeight: 1,
          }}>{special}</span>
        )}
      </div>
      {desc && (
        <p style={{
          fontFamily: 'Montserrat, sans-serif', fontSize: 14, color: '#5a6478',
          margin: '6px 0 0', lineHeight: 1.5,
        }}>{desc}</p>
      )}
    </div>
    <div style={{
      fontFamily: 'Cherston, "Big Shoulders Display", sans-serif',
      fontWeight: 700, fontSize: 22, letterSpacing: '0.005em',
      color: '#0a1f4a', whiteSpace: 'nowrap',
    }}>{price}</div>
  </div>
);

// Category header inside the full menu
const MenuCategory = ({ title, en, creature, children }) => (
  <section style={{ marginBottom: 72 }}>
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      borderBottom: '2px solid #0a1f4a', paddingBottom: 14, marginBottom: 4,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
        {creature && (
          <img src={`../../assets/icons/${creature}.png`}
               alt="" style={{ width: 56, height: 56, filter: 'brightness(0) saturate(100%) invert(8%) sepia(95%) saturate(2800%) hue-rotate(218deg) brightness(40%)' }} />
        )}
        <h3 style={{
          fontFamily: 'Cherston, "Big Shoulders Display", sans-serif',
          fontWeight: 900, fontSize: 44, lineHeight: 1,
          letterSpacing: '0.005em', textTransform: 'uppercase',
          color: '#0a1f4a', margin: 0,
        }}>{title}</h3>
      </div>
      <span style={{
        fontFamily: 'Montserrat, sans-serif', fontSize: 12, fontWeight: 500,
        letterSpacing: '0.2em', textTransform: 'uppercase', color: '#5a6478',
      }}>{en}</span>
    </div>
    <div>{children}</div>
  </section>
);

Object.assign(window, { MenuRow, MenuCategory });
