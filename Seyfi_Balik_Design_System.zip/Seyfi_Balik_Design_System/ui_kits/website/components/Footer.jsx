// Site footer — cobalt panel with creature scatter, hours, location, fine print.
const Footer = ({ setRoute }) => {
  return (
    <CreatureBg density="dense" opacity={0.10} style={{ padding: '96px 0 32px' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 40px', color: '#fff' }}>

        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1fr', gap: 48, marginBottom: 64 }}>
          <div>
            <Wordmark size="md" tone="on-blue" />
            <p style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 14, lineHeight: 1.6, color: 'rgba(255,255,255,0.72)', marginTop: 24, maxWidth: 320 }}>
              Yalıkavak iskelesinde, 1992'den beri. Bugün denizden ne çıkarsa, akşam menüde o.
            </p>
          </div>

          <FooterCol title="Açık · open">
            <FooterLine strong>Her gün<br />12:00 — 24:00</FooterLine>
            <FooterLine muted>Pazartesi kapalı</FooterLine>
          </FooterCol>

          <FooterCol title="Yer · find us">
            <FooterLine strong>İskele Caddesi 14<br />Yalıkavak, Bodrum</FooterLine>
            <FooterLine muted>Haritada aç ↗</FooterLine>
          </FooterCol>

          <FooterCol title="İletişim · contact">
            <FooterLine strong>+90 252 385 00 00</FooterLine>
            <FooterLine muted>merhaba@seyfibalik.com.tr</FooterLine>
            <FooterLine muted>Instagram</FooterLine>
          </FooterCol>
        </div>

        <div style={{
          borderTop: '1px solid rgba(255,255,255,0.18)', paddingTop: 24,
          display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 16,
          fontFamily: 'Montserrat, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.5)', letterSpacing: '0.06em',
        }}>
          <span>© 2026 Seyfi Balık · Yalıkavak</span>
          <span>seyfibalik.com.tr</span>
        </div>
      </div>
    </CreatureBg>
  );
};

const FooterCol = ({ title, children }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
    <div style={{
      fontFamily: 'Montserrat, sans-serif', fontSize: 11, fontWeight: 600,
      letterSpacing: '0.22em', textTransform: 'uppercase', color: '#f3b069',
    }}>{title}</div>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>{children}</div>
  </div>
);

const FooterLine = ({ children, strong, muted }) => (
  <span style={{
    fontFamily: strong
      ? 'Cherston, "Big Shoulders Display", sans-serif'
      : 'Montserrat, sans-serif',
    fontWeight: strong ? 700 : 400,
    fontSize: strong ? 17 : 14,
    letterSpacing: strong ? '0.005em' : 0,
    textTransform: strong ? 'uppercase' : 'none',
    lineHeight: strong ? 1.3 : 1.5,
    color: muted ? 'rgba(255,255,255,0.6)' : '#fff',
  }}>{children}</span>
);

Object.assign(window, { Footer });
