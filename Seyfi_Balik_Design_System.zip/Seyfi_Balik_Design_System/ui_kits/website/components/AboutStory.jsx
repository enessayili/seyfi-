// About / Hakkımızda page — story of the restaurant.
const AboutStory = () => {
  return (
    <main style={{ background: '#fbf8f1' }}>

      {/* Intro band — cobalt with creature scatter */}
      <CreatureBg density="normal" opacity={0.10} style={{ padding: '96px 0 80px' }}>
        <div style={{ maxWidth: 980, margin: '0 auto', padding: '0 40px', textAlign: 'center', color: '#fff' }}>
          <SectionHeader
            eyebrow="Hakkımızda · the story"
            title={<>Yalıkavak iskelesinde,<br />otuz iki yıldır</>}
            tone="dark"
            align="center"
          />
        </div>
      </CreatureBg>

      {/* Story body — alternating text + photo */}
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '128px 40px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 96, alignItems: 'center' }}>
        <div>
          <h3 style={{
            fontFamily: 'Cherston, "Big Shoulders Display", sans-serif',
            fontWeight: 900, fontSize: 40, lineHeight: 1.0,
            letterSpacing: '0.005em', textTransform: 'uppercase',
            color: '#0a1f4a', margin: 0,
          }}>Sabah erken<br />iskeledeyiz</h3>
          <p style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 17, lineHeight: 1.6, color: '#2a3a5c', marginTop: 24 }}>
            Seyfi Kaptan 1992'de bu yere demirledi. O zaman küçük bir tekne, dar bir mutfak, sekiz masaydı.
            Bugün hâlâ aynı kişi her sabah balıkçıyı karşılar — ne çıkmışsa o gün menüye o girer.
          </p>
          <p style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 17, lineHeight: 1.6, color: '#2a3a5c', marginTop: 16 }}>
            Sade pişiririz. Limon, zeytinyağı, tuz, taze ot — yeterli. İyi balık zaten kendi başına lezzetli.
          </p>
        </div>
        <div style={{ aspectRatio: '4/5', overflow: 'hidden' }}>
          <img src="../../assets/photos/scene-sea.jpg" alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        </div>
      </div>

      <div style={{ background: '#f4ede0', padding: '128px 0' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 40px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 96, alignItems: 'center' }}>
          <div style={{ aspectRatio: '4/5', overflow: 'hidden', order: 1 }}>
            <img src="../../assets/photos/scene-table.jpg" alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          </div>
          <div style={{ order: 2 }}>
            <h3 style={{
              fontFamily: 'Cherston, "Big Shoulders Display", sans-serif',
              fontWeight: 900, fontSize: 40, lineHeight: 1.0,
              letterSpacing: '0.005em', textTransform: 'uppercase',
              color: '#0a1f4a', margin: 0,
            }}>Manzara, masa,<br />sonra her şey</h3>
            <p style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 17, lineHeight: 1.6, color: '#2a3a5c', marginTop: 24 }}>
              İskelenin ucundayız. Akdeniz tam karşıda. Masalar zeytin ağacının altında — siz oturursunuz, gerisini biz hallederiz.
              Şarap listemiz Ege bağlarından, ekmek günlük, otlar bahçeden.
            </p>
            <p style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 17, lineHeight: 1.6, color: '#2a3a5c', marginTop: 16 }}>
              Bizi bulmak için Yalıkavak iskelesine yürüyün; en uçtaki mavi tabela.
            </p>
          </div>
        </div>
      </div>

      <div style={{ padding: '128px 40px', textAlign: 'center' }}>
        <div style={{ maxWidth: 720, margin: '0 auto' }}>
          <span style={{ fontFamily: 'Sacramento, Caveat, cursive', fontWeight: 700, fontSize: 56, color: '#e85a1e', lineHeight: 1, display: 'inline-block', transform: 'rotate(-3deg)' }}>Seyfi Kaptan</span>
          <p style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 13, fontWeight: 500, letterSpacing: '0.24em', textTransform: 'uppercase', color: '#5a6478', marginTop: 16 }}>kurucu · 1992</p>
        </div>
      </div>
    </main>
  );
};

Object.assign(window, { AboutStory });
