// Decorative creature scatter on cobalt panels.
// Renders many large white sea-creature illustrations at low opacity, rotated.
// `density` controls how many; `opacity` per-creature. Children render on top.
const CreatureBg = ({
  density = 'normal',          // 'sparse' | 'normal' | 'dense' | 'denser'
  opacity = 0.10,
  bg = '#16489f',
  style = {},
  children,
}) => {
  const sets = {
    sparse: [
      { src: 'octopus', top: '-40px', left: '-50px', size: 220, rot: -15 },
      { src: 'fish-folk', bottom: '8%', right: '-30px', size: 280, rot: -6, flip: true },
      { src: 'shrimp',  top: '55%',    left: '40%',  size: 180, rot: 12 },
    ],
    normal: [
      { src: 'octopus',   top: '-30px',   left: '-30px',  size: 210, rot: -15 },
      { src: 'fish-folk', top: '8%',      left: '34%',    size: 220, rot: -2 },
      { src: 'fish',      top: '38%',     right: '4%',    size: 180, rot: 8 },
      { src: 'shrimp',    bottom: '8%',   left: '12%',    size: 220, rot: -12 },
      { src: 'lobster',   bottom: '-20px',right: '-30px', size: 220, rot: 22 },
      { src: 'crab',      top: '52%',     left: '46%',    size: 160, rot: 10 },
      { src: 'fish-folk', bottom: '32%',  right: '32%',   size: 200, rot: -8, flip: true },
    ],
    dense: [
      { src: 'octopus',   top: '-30px',   left: '-30px',  size: 200, rot: -15 },
      { src: 'fish-folk', top: '6%',      left: '20%',    size: 200, rot: -4 },
      { src: 'crab',      top: '4%',      left: '52%',    size: 150, rot: 8 },
      { src: 'fish',      top: '12%',     right: '4%',    size: 170, rot: 10 },
      { src: 'shrimp',    top: '34%',     left: '-20px',  size: 200, rot: -10 },
      { src: 'lobster',   top: '32%',     left: '32%',    size: 180, rot: 18 },
      { src: 'fish-folk', top: '40%',     right: '14%',   size: 200, rot: -8, flip: true },
      { src: 'crab',      bottom: '8%',   left: '8%',     size: 150, rot: -14 },
      { src: 'shrimp',    bottom: '-10px',left: '36%',    size: 200, rot: 6 },
      { src: 'octopus',   bottom: '-30px',right: '20%',   size: 200, rot: 14 },
      { src: 'fish',      bottom: '14%',  right: '-30px', size: 200, rot: -16 },
    ],
    denser: [
      { src: 'octopus',   top: '-40px',   left: '-30px',  size: 200, rot: -15 },
      { src: 'fish-folk', top: '2%',      left: '20%',    size: 200, rot: -4 },
      { src: 'crab',      top: '4%',      left: '52%',    size: 140, rot: 8 },
      { src: 'fish',      top: '8%',      right: '4%',    size: 170, rot: 12 },
      { src: 'shrimp',    top: '22%',     left: '-30px',  size: 210, rot: -10 },
      { src: 'lobster',   top: '22%',     left: '36%',    size: 180, rot: 18 },
      { src: 'fish-folk', top: '26%',     right: '8%',    size: 200, rot: -6, flip: true },
      { src: 'crab',      top: '48%',     left: '12%',    size: 130, rot: -14 },
      { src: 'octopus',   top: '46%',     left: '40%',    size: 180, rot: 4 },
      { src: 'fish',      top: '50%',     right: '-30px', size: 200, rot: -18 },
      { src: 'shrimp',    bottom: '22%',  left: '-30px',  size: 200, rot: 8 },
      { src: 'fish-folk', bottom: '20%',  left: '32%',    size: 210, rot: 6 },
      { src: 'lobster',   bottom: '18%',  right: '16%',   size: 200, rot: 22 },
      { src: 'crab',      bottom: '-10px',left: '18%',    size: 150, rot: -10 },
      { src: 'octopus',   bottom: '-30px',right: '-20px', size: 200, rot: 14 },
      { src: 'fish',      bottom: '-10px',left: '56%',    size: 190, rot: 18 },
    ],
  };
  return (
    <div style={{ position: 'relative', overflow: 'hidden', background: bg, ...style }}>
      {sets[density].map((c, i) => (
        <img
          key={i}
          src={`../../assets/icons/${c.src}.png`}
          alt=""
          aria-hidden="true"
          style={{
            position: 'absolute',
            top: c.top, left: c.left, right: c.right, bottom: c.bottom,
            width: c.size + 'px',
            opacity,
            transform: `rotate(${c.rot}deg)${c.flip ? ' scaleX(-1)' : ''}`,
            pointerEvents: 'none',
            userSelect: 'none',
          }}
        />
      ))}
      <div style={{ position: 'relative', zIndex: 1, height: '100%' }}>{children}</div>
    </div>
  );
};

Object.assign(window, { CreatureBg });
