// Button variants. Theme: 'cream' (default light bg) | 'blue' (on cobalt)
const Button = ({ children, variant = 'primary', theme = 'cream', onClick, as = 'button', href, type = 'button', style = {} }) => {
  const base = {
    fontFamily: 'Montserrat, sans-serif',
    fontWeight: 500,
    fontSize: 13,
    letterSpacing: '0.08em',
    textTransform: 'uppercase',
    border: 0,
    borderRadius: 4,
    padding: '14px 28px',
    cursor: 'pointer',
    textDecoration: 'none',
    display: 'inline-flex',
    alignItems: 'center',
    gap: 10,
    transition: 'background 140ms cubic-bezier(.22,1,.36,1), color 140ms, transform 140ms, border-color 140ms',
    whiteSpace: 'nowrap',
  };
  const variants = {
    cream: {
      primary: { background: '#16489f', color: '#fff' },
      accent:  { background: '#e85a1e', color: '#fff' },
      outline: { background: 'transparent', color: '#0a1f4a', border: '1.5px solid #0a1f4a', padding: '12.5px 26.5px' },
      ghost:   { background: 'transparent', color: '#0a1f4a', padding: '14px 0', borderRadius: 0, textTransform: 'none', letterSpacing: 0, fontSize: 15, fontWeight: 500 },
      link:    { background: 'transparent', color: '#16489f', padding: '8px 0', textDecoration: 'underline', textUnderlineOffset: 5, borderRadius: 0 },
    },
    blue: {
      primary: { background: '#fff', color: '#0a1f4a' },
      accent:  { background: '#e85a1e', color: '#fff' },
      outline: { background: 'transparent', color: '#fff', border: '1.5px solid rgba(255,255,255,0.45)', padding: '12.5px 26.5px' },
      ghost:   { background: 'transparent', color: '#fff', padding: '14px 0', borderRadius: 0, textTransform: 'none', letterSpacing: 0, fontSize: 15, fontWeight: 500 },
      link:    { background: 'transparent', color: '#fff', padding: '8px 0', textDecoration: 'underline', textUnderlineOffset: 5, borderRadius: 0 },
    },
  };
  const Tag = as === 'a' ? 'a' : 'button';
  const props = as === 'a' ? { href } : { type, onClick };
  return <Tag {...props} style={{ ...base, ...variants[theme][variant], ...style }}>{children}</Tag>;
};

Object.assign(window, { Button });
