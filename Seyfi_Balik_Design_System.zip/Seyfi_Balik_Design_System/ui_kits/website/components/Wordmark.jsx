// The brand wordmark.
// Big white "Seyfi" (script) on top → folk fish centered → "BALIK" display below.
const Wordmark = ({ size = 'md', tone = 'on-blue' }) => {
  const sizes = {
    // [seyfiSize, fishSize, balikSize, gapTop, gapBot]
    sm: { seyfi:  44, fish:  48, balik: 16, gapTop: -8,  gapBot: -2 },
    md: { seyfi:  72, fish:  80, balik: 24, gapTop: -14, gapBot: -2 },
    lg: { seyfi: 120, fish: 130, balik: 40, gapTop: -22, gapBot: -4 },
    xl: { seyfi: 180, fish: 200, balik: 60, gapTop: -34, gapBot: -6 },
  };
  const s = sizes[size];
  const dark = tone === 'on-blue';
  const fg = dark ? '#fff' : '#0a1f4a';
  const fishSrc = dark
    ? ((typeof window !== 'undefined' && window.__SEYFI_FISH_SRC) || '../../assets/icons/fish-folk.png')
    : '../../assets/icons/fish-folk-navy.png';

  return (
    <div style={{
      display: 'inline-flex', flexDirection: 'column',
      alignItems: 'center', lineHeight: 1,
    }}>
      <span style={{
        fontFamily: 'Sacramento, Caveat, cursive',
        fontWeight: 400,
        color: fg,
        fontSize: s.seyfi,
        lineHeight: 0.85,
        transform: 'rotate(-3deg)',
        zIndex: 2,
      }}>Seyfi</span>

      <img
        src={fishSrc}
        alt=""
        aria-hidden="true"
        style={{
          width: s.fish,
          height: 'auto',
          marginTop: s.gapTop,
          marginBottom: s.gapBot,
        }}
      />

      <span style={{
        fontFamily: 'Cherston, "Big Shoulders Display", sans-serif',
        fontWeight: 900,
        color: fg,
        fontSize: s.balik,
        lineHeight: 0.9,
        letterSpacing: '0.18em',
        textTransform: 'uppercase',
        paddingLeft: '0.18em',  // optical: balance the right-side letter-spacing tail
      }}>Balık</span>
    </div>
  );
};

Object.assign(window, { Wordmark });
