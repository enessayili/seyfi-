// Full menu page.
const MenuPage = () => {
  return (
    <main style={{ background: '#fbf8f1', padding: '80px 0 128px' }}>
      <div style={{ maxWidth: 980, margin: '0 auto', padding: '0 40px' }}>

        <SectionHeader
          eyebrow="Menü · spring & summer 2026"
          title="Bugünün menüsü"
          lede="Listemiz her gün denizden gelene göre değişir. Aşağıdakiler son hafta servis ettiklerimiz — yıldızla işaretli olanlar bugün masada."
        />

        <div style={{ marginTop: 64 }}>

          <MenuCategory title="Mezeler" en="Mezze" creature="crab">
            <MenuRow name="Deniz börülcesi" desc="zeytinyağı · sarımsak · limon" price="₺240" />
            <MenuRow name="Ahtapot salatası" desc="patates · soğan · maydanoz" price="₺380" special="bugün" />
            <MenuRow name="Çiroz" desc="ızgara, hardal soslu" price="₺320" />
            <MenuRow name="Lakerda" desc="kuzu palamuttan, geleneksel" price="₺360" />
            <MenuRow name="Kalamar tava" desc="aioli · limon" price="₺420" />
            <MenuRow name="Midye dolma (6 adet)" desc="bademli iç pilav, taze limon" price="₺220" />
          </MenuCategory>

          <MenuCategory title="Tarladan" en="From the garden" creature="shrimp">
            <MenuRow name="Yaprak salata" desc="taze otlar · zeytinyağı · limon" price="₺180" />
            <MenuRow name="Domates · peynir · fesleğen" desc="Bozcaada peyniri" price="₺240" />
            <MenuRow name="Közlenmiş biber" desc="sarımsak · zeytinyağı · ceviz" price="₺220" />
            <MenuRow name="Karpuz · beyaz peynir" desc="taze nane" price="₺200" />
          </MenuCategory>

          <MenuCategory title="Ana Yemekler" en="From the sea" creature="fish">
            <MenuRow name="Çupra ızgara" desc="limon · zeytinyağı · roka" price="₺680" />
            <MenuRow name="Levrek buğulama" desc="domates · kapari · taze fesleğen" price="₺720" special="bugün" />
            <MenuRow name="Lahos ızgara" desc="günlük, parça pişirilir — sorunuz" price="₺piyasa" />
            <MenuRow name="Ahtapot ızgara" desc="közlenmiş biber · roka" price="₺780" special="bugün" />
            <MenuRow name="Mürekkep balıklı risotto" desc="parmesan · taze otlar" price="₺620" />
            <MenuRow name="Karides güveç" desc="domates · beyaz şarap · taze ot" price="₺640" />
          </MenuCategory>

          <MenuCategory title="Şefin masası" en="Chef's table" creature="lobster">
            <MenuRow name="Istakoz tabağı · 2 kişilik" desc="beyaz şarap soslu · kuşkonmaz" price="₺1.640" />
            <MenuRow name="Akdeniz tabağı · 4 kişilik" desc="balık · karides · ahtapot · midye" price="₺2.480" />
          </MenuCategory>

          <MenuCategory title="Tatlılar" en="Sweet">
            <MenuRow name="Sakızlı dondurma" desc="ev yapımı" price="₺140" />
            <MenuRow name="Mevsim meyveleri" desc="kavun · karpuz · incir" price="₺160" />
            <MenuRow name="Taze incir, beyaz peynir, ceviz" desc="bal akar" price="₺220" />
          </MenuCategory>

        </div>

        <p style={{
          fontFamily: 'Montserrat, sans-serif', fontSize: 13, color: '#5a6478',
          marginTop: 56, textAlign: 'center', lineHeight: 1.6,
        }}>
          Fiyatlar TL · KDV dahildir. Günlük balık fiyatları piyasaya göre değişebilir, garsonunuza sorunuz.
        </p>
      </div>
    </main>
  );
};

Object.assign(window, { MenuPage });
