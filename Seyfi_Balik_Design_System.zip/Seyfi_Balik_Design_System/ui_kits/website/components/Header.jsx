// Sticky cobalt-blurred header for the website.
const Header = ({ route, setRoute }) => {
  const links = [
    { id: '/menu',         tr: 'Menü',         en: 'menu' },
    { id: '/hakkimizda',   tr: 'Hakkımızda',   en: 'about' },
    { id: '/rezervasyon',  tr: 'Rezervasyon',  en: 'reserve' },
  ];
  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 50,
      background: 'rgba(22, 72, 159, 0.86)',
      backdropFilter: 'blur(14px) saturate(140%)',
      WebkitBackdropFilter: 'blur(14px) saturate(140%)',
      borderBottom: '1px solid rgba(255,255,255,0.12)',
      color: '#fff',
    }}>
      <div style={{
        maxWidth: 1280, margin: '0 auto',
        padding: '14px 40px',
        display: 'grid', gridTemplateColumns: '1fr auto 1fr',
        alignItems: 'center', gap: 24,
      }}>
        <a href="#/" onClick={(e) => { e.preventDefault(); setRoute('/'); }}
           style={{ display: 'inline-flex', alignItems: 'center', textDecoration: 'none' }}>
          <Wordmark size="sm" tone="on-blue" />
        </a>
        <nav style={{ display: 'flex', gap: 32, justifyContent: 'center' }}>
          {links.map(l => {
            const active = route === l.id;
            return (
              <a key={l.id} href={'#' + l.id}
                 onClick={(e) => { e.preventDefault(); setRoute(l.id); }}
                 style={{
                   color: active ? '#fff' : 'rgba(255,255,255,0.72)',
                   fontFamily: 'Montserrat, sans-serif',
                   fontSize: 13, fontWeight: 500,
                   letterSpacing: '0.16em', textTransform: 'uppercase',
                   textDecoration: 'none',
                   borderBottom: active ? '1.5px solid #fff' : '1.5px solid transparent',
                   padding: '6px 0',
                   transition: 'color 140ms, border-color 140ms',
                 }}>{l.tr}</a>
            );
          })}
        </nav>
        <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: 16 }}>
          <span style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.65)', letterSpacing: '0.06em' }}>
            +90 252 385 00 00
          </span>
          <Button variant="primary" theme="blue" onClick={() => setRoute('/rezervasyon')}>Masa rezerve et</Button>
        </div>
      </div>
    </header>
  );
};

Object.assign(window, { Header });
