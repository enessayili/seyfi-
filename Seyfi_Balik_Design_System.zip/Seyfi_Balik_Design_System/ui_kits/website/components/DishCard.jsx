// Single dish card (photo + name + desc + price). Used in DailyCatch grid.
const DishCard = ({ photo, category, name, desc, price, special }) => {
  const [hover, setHover] = React.useState(false);
  return (
    <article
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        background: '#fff',
        border: '1px solid rgba(10,31,74,0.10)',
        transform: hover ? 'translateY(-2px)' : 'translateY(0)',
        boxShadow: hover ? '0 6px 24px -8px rgba(10,31,74,0.18)' : 'none',
        transition: 'all 260ms cubic-bezier(.22,1,.36,1)',
        display: 'flex', flexDirection: 'column',
      }}>
      <div style={{ aspectRatio: '4/3', overflow: 'hidden', background: '#eee' }}>
        <img src={photo} alt={name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
      </div>
      <div style={{ padding: '22px 22px 24px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        <div style={{
          fontFamily: 'Montserrat, sans-serif', fontSize: 11, fontWeight: 600,
          letterSpacing: '0.2em', textTransform: 'uppercase', color: '#5a6478',
        }}>{category}</div>
        <h3 style={{
          fontFamily: 'Cherston, "Big Shoulders Display", sans-serif',
          fontWeight: 700, fontSize: 26, lineHeight: 1.05,
          letterSpacing: '0.005em', textTransform: 'uppercase',
          color: '#0a1f4a', margin: 0,
        }}>{name}</h3>
        <p style={{
          fontFamily: 'Montserrat, sans-serif', fontSize: 14, lineHeight: 1.55,
          color: '#5a6478', margin: 0,
        }}>{desc}</p>
        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
          marginTop: 8, paddingTop: 12, borderTop: '1px solid rgba(10,31,74,0.10)',
        }}>
          <span style={{
            fontFamily: 'Cherston, "Big Shoulders Display", sans-serif',
            fontWeight: 700, fontSize: 22, color: '#0a1f4a', letterSpacing: '0.005em',
          }}>{price}</span>
          {special && (
            <span style={{
              fontFamily: 'Sacramento, Caveat, cursive', fontWeight: 700, fontSize: 22, color: '#16489f',
            }}>{special}</span>
          )}
        </div>
      </div>
    </article>
  );
};

Object.assign(window, { DishCard });
