// Section header — eyebrow + display + lede. Use throughout.
const SectionHeader = ({ eyebrow, title, lede, tone = 'light', align = 'left', maxWidth = 580 }) => {
  const eyeColor    = tone === 'dark' ? '#f3b069' : '#e85a1e';
  const titleColor  = tone === 'dark' ? '#fff'    : '#0a1f4a';
  const ledeColor   = tone === 'dark' ? 'rgba(255,255,255,0.78)' : '#2a3a5c';
  return (
    <div style={{ textAlign: align, marginLeft: align === 'center' ? 'auto' : 0, marginRight: align === 'center' ? 'auto' : 0, maxWidth }}>
      {eyebrow && (
        <div style={{
          fontFamily: 'Montserrat, sans-serif', fontSize: 12, fontWeight: 600,
          letterSpacing: '0.22em', textTransform: 'uppercase',
          color: eyeColor, marginBottom: 18,
        }}>{eyebrow}</div>
      )}
      <h2 style={{
        fontFamily: 'Cherston, "Big Shoulders Display", sans-serif',
        fontWeight: 900, fontSize: 'clamp(36px, 4.6vw, 64px)',
        lineHeight: 0.95, letterSpacing: '0.005em',
        textTransform: 'uppercase', color: titleColor, margin: 0,
      }}>{title}</h2>
      {lede && (
        <p style={{
          fontFamily: 'Montserrat, sans-serif', fontSize: 18,
          lineHeight: 1.55, color: ledeColor, margin: '20px 0 0',
          maxWidth: 540, marginLeft: align === 'center' ? 'auto' : 0, marginRight: align === 'center' ? 'auto' : 0,
        }}>{lede}</p>
      )}
    </div>
  );
};

Object.assign(window, { SectionHeader });
