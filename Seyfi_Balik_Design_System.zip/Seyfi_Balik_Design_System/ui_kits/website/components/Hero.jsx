// Hero panel for homepage. Cobalt + dense creature scatter + heritage badge + wordmark.
const Hero = ({ setRoute }) => {
  return (
    <CreatureBg density="denser" opacity={0.11} style={{ minHeight: 720 }}>
      <div style={{
        maxWidth: 1280, margin: '0 auto',
        padding: '88px 40px 72px',
        display: 'grid', gridTemplateColumns: '1.1fr 0.9fr', gap: 64,
        alignItems: 'center', minHeight: 720, color: '#fff',
      }}>
        <div>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 14,
            marginBottom: 28,
          }}>
            <img src="../../assets/logos/seyfi-badge-heritage.jpg"
                 alt="Seyfi Balık Restoranı"
                 style={{
                   width: 56, height: 56, borderRadius: '50%',
                   boxShadow: '0 0 0 2px rgba(255,255,255,0.18), 0 8px 24px rgba(0,0,0,0.3)',
                 }} />
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              <span style={{
                fontFamily: 'Montserrat, sans-serif', fontSize: 11, fontWeight: 600,
                letterSpacing: '0.32em', textTransform: 'uppercase',
                color: '#fff', lineHeight: 1.2,
              }}>Yalıkavak iskelesi</span>
              <span style={{
                fontFamily: 'Montserrat, sans-serif', fontSize: 11, fontWeight: 500,
                letterSpacing: '0.32em', textTransform: 'uppercase',
                color: 'rgba(255,255,255,0.55)', lineHeight: 1.2, marginTop: 2,
              }}>est. 1992</span>
            </div>
          </div>

          <div style={{ marginLeft: -4 }}>
            <div style={{ display: 'inline-flex', flexDirection: 'column', alignItems: 'flex-start' }}>
              <span style={{
                fontFamily: 'Sacramento, Caveat, cursive', fontWeight: 400, color: '#fff',
                fontSize: 180, lineHeight: 0.85, transform: 'rotate(-3deg)',
                zIndex: 2, marginBottom: -36, textShadow: '0 2px 20px rgba(0,0,0,0.2)',
              }}>Seyfi</span>
              <img src="../../assets/icons/fish-folk.png" alt="" aria-hidden="true"
                   style={{ width: 220, display: 'block', marginLeft: 30 }} />
              <span style={{
                fontFamily: 'Cherston, "Big Shoulders Display", sans-serif',
                fontWeight: 900, color: '#fff', fontSize: 64,
                lineHeight: 0.85, letterSpacing: '0.18em',
                textTransform: 'uppercase', paddingLeft: '0.18em',
                marginTop: 4, marginLeft: 30,
              }}>Balık</span>
            </div>
          </div>

          <p style={{
            fontFamily: 'Montserrat, sans-serif', fontSize: 19,
            lineHeight: 1.55, color: 'rgba(255,255,255,0.84)',
            marginTop: 40, maxWidth: 480,
          }}>
            Bugün denizden ne çıkarsa, akşam menüde o var. Otuz iki yıldır
            sade pişiririz — limon, zeytinyağı, taze ot.
          </p>

          <div style={{ display: 'flex', gap: 14, marginTop: 32, flexWrap: 'wrap' }}>
            <Button variant="primary" theme="blue" onClick={() => setRoute('/rezervasyon')}>Masa rezerve et</Button>
            <Button variant="outline" theme="blue" onClick={() => setRoute('/menu')}>Menüyü gör</Button>
          </div>
        </div>

        <div style={{ position: 'relative', aspectRatio: '3/4', maxHeight: 580, overflow: 'hidden' }}>
          <img src="../../assets/photos/dish-fish-baked.jpg"
               alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          <div style={{
            position: 'absolute', left: -8, bottom: 28,
            background: '#e85a1e', color: '#fff',
            fontFamily: 'Sacramento, Caveat, cursive', fontWeight: 400,
            fontSize: 36, padding: '4px 18px 8px', lineHeight: 1,
            transform: 'rotate(-3deg)',
          }}>bugün taze</div>
        </div>
      </div>
    </CreatureBg>
  );
};

Object.assign(window, { Hero });
