// Reservation page with form.
const Reservation = () => {
  const [form, setForm] = React.useState({
    date: '14 Haziran 2026',
    time: '20:30',
    party: '2',
    name: '',
    phone: '',
    note: '',
  });
  const [sent, setSent] = React.useState(false);
  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  if (sent) {
    return (
      <CreatureBg density="dense" opacity={0.10} style={{ minHeight: '70vh' }}>
        <div style={{ maxWidth: 720, margin: '0 auto', padding: '120px 40px', color: '#fff', textAlign: 'center' }}>
          <div style={{ fontFamily: 'Sacramento, Caveat, cursive', fontWeight: 700, fontSize: 64, color: '#e85a1e', transform: 'rotate(-3deg)', marginBottom: 8 }}>teşekkürler</div>
          <h1 style={{
            fontFamily: 'Cherston, "Big Shoulders Display", sans-serif',
            fontWeight: 900, fontSize: 56, letterSpacing: '0.005em',
            textTransform: 'uppercase', margin: 0,
          }}>Masanız ayrıldı</h1>
          <p style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 18, color: 'rgba(255,255,255,0.78)', lineHeight: 1.55, marginTop: 24 }}>
            {form.date} akşamı, saat {form.time}'de {form.party} kişilik. Onay mesajı telefonunuza geldi.
          </p>
          <p style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 15, color: 'rgba(255,255,255,0.6)', marginTop: 16 }}>
            Aklınız değişirse +90 252 385 00 00 — arayın yeter.
          </p>
        </div>
      </CreatureBg>
    );
  }

  const Field = ({ label, children }) => (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <span style={{
        fontFamily: 'Montserrat, sans-serif', fontSize: 11, fontWeight: 600,
        letterSpacing: '0.2em', textTransform: 'uppercase', color: '#5a6478',
      }}>{label}</span>
      {children}
    </label>
  );

  const inputStyle = {
    fontFamily: 'Montserrat, sans-serif', fontSize: 16, color: '#0a1f4a',
    background: '#fff', border: '1px solid rgba(10,31,74,0.20)',
    borderRadius: 2, padding: '14px 16px',
    boxShadow: '0 1px 2px rgba(10,31,74,0.06)', outline: 'none',
  };

  return (
    <CreatureBg density="dense" opacity={0.10} style={{ padding: '80px 0 128px' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 40px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'start' }}>

        <div>
          <SectionHeader
            eyebrow="Rezervasyon · book a table"
            title={<>Bu akşam<br />bir masa</>}
            tone="dark"
            lede="Akşam yemeği için günlük rezervasyon alıyoruz. Hafta sonları en az iki gün önceden ayırmanızı öneririz. Cuma akşamları masamız genellikle 10 gün öncesinden dolar."
          />

          <div style={{ marginTop: 48, padding: '24px 28px', border: '1px solid rgba(255,255,255,0.2)', background: 'rgba(255,255,255,0.04)', display: 'flex', flexDirection: 'column', gap: 14, color: '#fff' }}>
            <div>
              <div style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 11, fontWeight: 600, letterSpacing: '0.2em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.7)' }}>Açık</div>
              <div style={{ fontFamily: 'Cherston, "Big Shoulders Display", sans-serif', fontWeight: 700, fontSize: 19, color: '#fff', marginTop: 4, letterSpacing: '0.005em', textTransform: 'uppercase' }}>Her gün · 12:00 — 24:00</div>
              <div style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 14, color: 'rgba(255,255,255,0.62)', marginTop: 2 }}>Pazartesi kapalı</div>
            </div>
            <div>
              <div style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 11, fontWeight: 600, letterSpacing: '0.2em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.7)' }}>Telefon</div>
              <div style={{ fontFamily: 'Cherston, "Big Shoulders Display", sans-serif', fontWeight: 700, fontSize: 19, color: '#fff', marginTop: 4, letterSpacing: '0.005em', textTransform: 'uppercase' }}>+90 252 385 00 00</div>
            </div>
          </div>
        </div>

        <form onSubmit={(e) => { e.preventDefault(); setSent(true); }}
              style={{ background: '#fff', padding: 36, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, boxShadow: '0 24px 60px -24px rgba(0,0,0,0.4)' }}>
          <Field label="Tarih"><input style={inputStyle} value={form.date} onChange={set('date')} /></Field>
          <Field label="Saat"><input style={inputStyle} value={form.time} onChange={set('time')} /></Field>
          <Field label="Kaç kişi"><input style={inputStyle} value={form.party} onChange={set('party')} /></Field>
          <Field label="Telefon"><input style={inputStyle} placeholder="+90 5__ ___ __ __" value={form.phone} onChange={set('phone')} /></Field>
          <div style={{ gridColumn: '1/-1' }}>
            <Field label="Adınız"><input style={inputStyle} placeholder="Adınız Soyadınız" value={form.name} onChange={set('name')} /></Field>
          </div>
          <div style={{ gridColumn: '1/-1' }}>
            <Field label="Not (isteğe bağlı)">
              <textarea style={{ ...inputStyle, fontFamily: 'Montserrat, sans-serif', minHeight: 80, resize: 'vertical' }}
                        placeholder="Deniz manzaralı masa, doğum günü, alerji…"
                        value={form.note} onChange={set('note')} />
            </Field>
          </div>
          <div style={{ gridColumn: '1/-1', marginTop: 8, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
            <span style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 12, color: '#5a6478' }}>
              Onayı SMS olarak alacaksınız.
            </span>
            <Button type="submit" variant="primary" theme="cream">Rezervasyonu tamamla</Button>
          </div>
        </form>

      </div>
    </CreatureBg>
  );
};

Object.assign(window, { Reservation });
