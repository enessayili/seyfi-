// "Bugün masada" — homepage section featuring today's catch as 3 dish cards.
const DailyCatch = ({ setRoute }) => {
  const dishes = [
    {
      photo: '../../assets/photos/dish-fish-baked.jpg',
      category: 'Ana yemek',
      name: 'Levrek buğulama',
      desc: 'Domates, kapari ve taze fesleğenle. Egeli bir klasik.',
      price: '₺720',
      special: 'taze, bugün',
    },
    {
      photo: '../../assets/photos/dish-shrimp.jpg',
      category: 'Meze',
      name: 'Karides buz üstünde',
      desc: 'Limon ve dereotuyla. Sade.',
      price: '₺580',
      special: null,
    },
    {
      photo: '../../assets/photos/dish-lobster.jpg',
      category: 'Şefin seçimi',
      name: 'Istakoz tabağı',
      desc: 'Beyaz şarap soslu, kuşkonmaz garnitürlü. 2 kişilik.',
      price: '₺1.640',
      special: null,
    },
  ];

  return (
    <section style={{ background: '#fbf8f1', padding: '128px 0' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 40px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 56, gap: 40, flexWrap: 'wrap' }}>
          <SectionHeader
            eyebrow="Bugün masada · today's catch"
            title={<>Taze balık,<br />taze lezzet</>}
            lede="Sabah erken, iskeleden. Akşam tabakta. Listemiz her gün değişir — bugün biz de görmeden bilmiyoruz."
          />
          <Button variant="link" theme="cream" onClick={() => setRoute('/menu')}>Tüm menüyü gör →</Button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 24 }}>
          {dishes.map((d, i) => <DishCard key={i} {...d} />)}
        </div>
      </div>
    </section>
  );
};

Object.assign(window, { DailyCatch });
