// Root App with hash-based routing.
const useHashRoute = () => {
  const [route, setRouteState] = React.useState(() => (window.location.hash.replace('#', '') || '/'));
  React.useEffect(() => {
    const onHash = () => setRouteState(window.location.hash.replace('#', '') || '/');
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  const setRoute = (next) => {
    window.location.hash = next;
    setRouteState(next);
    window.scrollTo({ top: 0, behavior: 'instant' });
  };
  return [route, setRoute];
};

const App = () => {
  const [route, setRoute] = useHashRoute();

  let body;
  if (route === '/menu') {
    body = <MenuPage />;
  } else if (route === '/rezervasyon') {
    body = <Reservation />;
  } else if (route === '/hakkimizda') {
    body = <AboutStory />;
  } else {
    body = (
      <>
        <Hero setRoute={setRoute} />
        <DailyCatch setRoute={setRoute} />
        <PhotoStrip />
        <AboutTeaser setRoute={setRoute} />
        <BookCTA setRoute={setRoute} />
      </>
    );
  }

  return (
    <div data-screen-label={routeLabel(route)} style={{ background: '#0e2f6e', minHeight: '100vh' }}>
      <Header route={route} setRoute={setRoute} />
      {body}
      <Footer setRoute={setRoute} />
    </div>
  );
};

const routeLabel = (r) => {
  switch (r) {
    case '/menu': return 'Menu';
    case '/rezervasyon': return 'Reservation';
    case '/hakkimizda': return 'About';
    default: return 'Home';
  }
};

// Homepage-only sub-sections that aren't worth their own file:

const PhotoStrip = () => (
  <section style={{ background: '#fbf8f1', padding: '0' }}>
    <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 40px 128px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr 1fr', gridTemplateRows: '240px 240px', gap: 6 }}>
        <img src="../../assets/photos/dish-spread.jpg" alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', gridRow: '1 / -1' }} />
        <img src="../../assets/photos/scene-table.jpg" alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        <img src="../../assets/photos/dish-bread.jpg" alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        <img src="../../assets/photos/scene-sea.jpg" alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        <img src="../../assets/photos/dish-lobster.jpg" alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
      </div>
    </div>
  </section>
);

const AboutTeaser = ({ setRoute }) => (
  <section style={{ background: '#f4ede0', padding: '128px 0' }}>
    <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 40px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 96, alignItems: 'center' }}>
      <div style={{ aspectRatio: '4/5', overflow: 'hidden' }}>
        <img src="../../assets/photos/scene-cheers.jpg" alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
      </div>
      <div>
        <SectionHeader
          eyebrow="Hakkımızda · the story"
          title={<>İskelenin<br />ucundayız</>}
          lede="1992'den beri aynı yerde, aynı kişi. Sabah erken iskelede balıkçıyı karşılar, akşam siz masaya oturursunuz. Aramızda olan tek şey: limon, zeytinyağı, tuz."
        />
        <div style={{ marginTop: 32 }}>
          <Button variant="outline" theme="cream" onClick={() => setRoute('/hakkimizda')}>Devamını oku →</Button>
        </div>
      </div>
    </div>
  </section>
);

const BookCTA = ({ setRoute }) => (
    <CreatureBg density="dense" opacity={0.11} style={{ padding: '128px 0' }}>
    <div style={{ maxWidth: 880, margin: '0 auto', padding: '0 40px', textAlign: 'center', color: '#fff' }}>
      <span style={{ fontFamily: 'Sacramento, Caveat, cursive', fontWeight: 700, color: '#fff', fontSize: 44, lineHeight: 1, transform: 'rotate(-3deg)', display: 'inline-block', marginBottom: 12 }}>
        bu akşam
      </span>
      <h2 style={{
        fontFamily: 'Cherston, "Big Shoulders Display", sans-serif',
        fontWeight: 900, fontSize: 'clamp(48px, 6vw, 88px)',
        lineHeight: 0.92, letterSpacing: '0.005em',
        textTransform: 'uppercase', margin: 0,
      }}>Bir masa<br />sizinle başlasın</h2>
      <p style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 19, lineHeight: 1.55, color: 'rgba(255,255,255,0.82)', margin: '24px auto 0', maxWidth: 520 }}>
        Hafta sonları masa erken biter. En iyisi bugünden ayırtın.
      </p>
      <div style={{ marginTop: 36, display: 'inline-flex', gap: 12, flexWrap: 'wrap', justifyContent: 'center' }}>
        <Button variant="primary" theme="blue" onClick={() => setRoute('/rezervasyon')}>Masa rezerve et</Button>
        <Button variant="outline" theme="blue" as="a" href="tel:+902523850000">+90 252 385 00 00</Button>
      </div>
    </div>
  </CreatureBg>
);

Object.assign(window, { App });
