# Seyfi Balık — Website UI Kit

A hi-fi recreation of the upcoming **Seyfi Balık** restaurant website (`seyfibalik.com.tr`). This kit was not derived from an existing codebase — it's the design system put into practice as the first reference build. The client will rebuild this in Claude Code with this kit as the visual target.

## Run

Open `index.html` in a browser. No build step. Uses CDN React + Babel.

## Screens

Hash-based routing in `App.jsx`:

| Route | Screen |
|---|---|
| `#/` | **Homepage** — hero, daily catch, menu preview, story, reservation CTA |
| `#/menu` | **Menu** — full menu, categories, daily-special markers |
| `#/rezervasyon` | **Reservation** — booking form |
| `#/hakkimizda` | **About** — story of the restaurant, Yalıkavak |

## Components

- `Header.jsx` — sticky cobalt-blurred top nav with wordmark + reservation CTA
- `Hero.jsx` — full-bleed cobalt panel with creature scatter, mega wordmark, tagline
- `CreatureBg.jsx` — the signature **tiled creature pattern** decorator
- `Wordmark.jsx` — *Seyfi* script + **BALIK** display
- `SectionHeader.jsx` — eyebrow + display headline + lede
- `Buttons.jsx` — primary, accent, outline, ghost variants
- `DishCard.jsx` — photo + name + description + price
- `MenuRow.jsx` — single line in the long menu, with daily-special marker
- `DailyCatch.jsx` — homepage "Today's catch" section, 3-up
- `MenuPage.jsx` — full categorized menu
- `Reservation.jsx` — booking form
- `AboutStory.jsx` — side-by-side text + photo about page
- `Footer.jsx` — hours, location, social, fine print

## Conventions

- All copy is **Turkish first**, with English subtitles where helpful (matches `seyfibalik.com.tr` audience).
- Photos are pulled from `../../assets/photos/`.
- Creature illustrations from `../../assets/icons/`.
- All colors/type come from the project root `colors_and_type.css` (imported at the top of `index.html`).

## What's intentionally not here

- Real reservation backend — form is decorative.
- Internationalization — copy is bilingual but no i18n machinery.
- Image optimization — full-size source photos.
- Mobile breakpoints — kit is laid out for desktop preview (≥1280 px). The website build should adapt.
