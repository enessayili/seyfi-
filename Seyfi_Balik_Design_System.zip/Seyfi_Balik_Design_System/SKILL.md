---
name: seyfi-balik-design
description: Use this skill to generate well-branded interfaces and assets for Seyfi Balık (Yalıkavak seafood restaurant), either for production or throwaway prototypes/mocks/decks. Contains essential design guidelines, colors, type, fonts, sea-creature illustration system, photography references, and a working website UI kit for prototyping.
user-invocable: true
---

Read the `README.md` file at the root of this skill, then explore the rest:

- `colors_and_type.css` — drop-in design tokens. Always import this rather than re-typing values.
- `assets/icons/` — the five white-on-transparent engraved sea creatures (octopus, fish, crab, lobster, shrimp). The brand's "icons" — never substitute with a generic icon set.
- `assets/photos/` — reference photography (warm Mediterranean food + scenes).
- `ui_kits/website/` — a hi-fi clickable mock of the upcoming `seyfibalik.com.tr`. Lift its components when prototyping web work.
- `preview/` — small static cards demonstrating each token / component.

If creating visual artifacts (slides, mocks, throwaway prototypes, posters): copy what you need into the output and produce static HTML files for the user to view.

If working on production code: read `README.md` end to end, then use the rules in **VISUAL FOUNDATIONS** and **CONTENT FUNDAMENTALS** to write correct CSS and copy. The `ui_kits/website/` components are simplified React — re-write them in whatever framework the production codebase uses.

If the user invokes this skill without specific guidance, ask:
1. What are they building? (website page, social post, menu PDF, signage, deck, app screen?)
2. What's the surface — print, web, mobile, large signage?
3. Turkish, English, or both?
4. Cobalt-on-white or cobalt-dominant background?

Then act as an expert designer who outputs HTML artifacts or production code.

## Hard rules to never break

- **Colors**: cobalt (`#16489f`) and white are the dominant pairing. Cream (`#f4ede0`) is a rare warm note. Orange (`#e85a1e`) is a **spark** — one mark per screen, max, and never as a background or body text.
- **Type**: Cherston for display (paid — Big Shoulders Display is the free fallback), Montserrat for body, Caveat or Cherston Script (→ Allura fallback) for accents. Body never below 17 px.
- **Icons**: never use Lucide/Heroicons in marketing surfaces. Use the engraved creatures, white-on-cobalt. Lucide is only acceptable for functional UI controls (close, menu, phone, location).
- **No emoji.** Anywhere.
- **No exclamation marks** in body copy. No "premium", "lüks", "deluxe".
- **Hover/press** = color shifts and 2-pixel lifts, never scale or bounce.
- **Corners** are sharp by default (0 px). Only buttons (4 px) and chips (pill) break this.
