# Seyfi Balık — Design System

> **Seyfi Balık** is a seafood restaurant in **Yalıkavak, Bodrum** — a coastal town on Turkey's Aegean. This design system is being built ahead of the brand's first website, which the client plans to build in Claude Code. It captures everything a designer or developer needs to put the brand on screen consistently: colors, typography, the engraved sea-creature illustration system, photography direction, and a working website UI kit.

---

## What's in this project

| Path | What it is |
|---|---|
| `colors_and_type.css` | All CSS custom properties — colors, type, spacing, radii, shadows, motion. Import this into any artifact. |
| `assets/icons/` | The five hand-drawn sea creatures (octopus, fish, crab, lobster, shrimp), white-on-transparent, ready to tile on cobalt. |
| `assets/photos/` | Source photography — dishes, scenes, posters — for reference & use in mocks. |
| `preview/` | Static cards that populate the Design System tab. |
| `ui_kits/website/` | Hi-fi recreation of the upcoming Seyfi website. Components + a clickable `index.html`. |
| `source_images/` | Original references provided by the user. |
| `SKILL.md` | Cross-compatible skill manifest — also valid for Claude Code. |

## Sources & references

The user provided:
- A folder of 17 photos shot at high-end seafood restaurants (Bodrum / Côte d'Azur / Sydney style) that defines the **food + scene aesthetic**.
- 3 reference posters using a cobalt-blue palette with vintage engraved fish/shrimp art (`source_images/2.jpg`, `3.jpg`, `17.jpg`) — this is the **graphic direction**.
- 5 AI-generated engravings (`a.png`, `gen1–4.png`): octopus, fish, crab, lobster, shrimp on cobalt. These are the **brand creature set**.
- A user note (Turkish): main color **blue** like the photos, **white**, third color **orange**; he wants the engraved creatures **tiled in white** as background pattern; site will be built in Claude Code.

> No existing codebase, Figma, or live website was provided — this system is being **established from scratch** based on the references above.

---

## At a glance

- **Cobalt blue, paper cream, vermillion orange.** That's the whole palette. Don't add more.
- **Engraved sea creatures are the visual signature.** White, ghosted, tiled on blue — never bright, never colored.
- **Display type is a tall, fat, italic-capable serif** (Bodoni Moda). Body is a calm grotesque (DM Sans). A handwritten script (Caveat) is reserved for accents only.
- **No icons in the UI-element sense.** Don't use Lucide/Heroicons in marketing pages. The creatures *are* the icons.
- **Photography is warm, bright, sunlit Mediterranean.** Plates on linen, sea in the bokeh, lemon, parsley, terracotta.
- **Corners are sharp.** Buttons get only a 2–4 px radius. Cards have a hairline rule, not a shadow.

---

## CONTENT FUNDAMENTALS

**Language.** The site will ship in **Turkish first, English second**. Copy in this system is given in both where it matters.

**Voice.** Confident, modest, generous. Like a fisherman who has been opening his place every summer for thirty years and doesn't need to oversell it. It's never breathless, never "elevated," never "redefining." It states.

**Tone in one sentence.**
> *Bugün denizden ne çıkarsa, akşam tabakta o var.* — "Whatever comes out of the sea today, that's on the plate tonight."

**You vs. we.** Use **"biz"** ("we") for the restaurant — warm, familial. Address the guest in singular **"siz"** (formal Turkish "you"), never "sen". In English: "we" and "you", always lowercase, never YELLING.

**Casing.**
- Display headlines: **ALL CAPS** for the "signage" feel (matches the engraved posters): *TAZE BALIK · TAZE LEZZET*.
- Body copy: **sentence case**. Never title case.
- Menu item names: **Sentence case** ("Çupra ızgara", not "Çupra Izgara").
- Eyebrows / section labels: **ALL CAPS, wide tracking** (0.18em): *GÜNÜN MENÜSÜ · MENU OF THE DAY*.

**Punctuation.**
- Use the Turkish dotted-İ correctly: *Balık*, *İskele*.
- Use ` · ` (middle dot) as the divider between two short phrases on a single line. It's the brand's house separator.
- Em-dash — like this — for asides. No spaces around in body, spaces in display.
- Numbers in menu prices use a `₺` prefix with no decimals: `₺680`.

**Emoji.** **No.** Never in marketing, never in the UI. The engraved creatures are the only "icons" the brand uses.

**Examples — write like this:**

> Yalıkavak iskelesinde, otuz iki yıldır. Bugün denizden ne çıkarsa, akşam menüde o.

> Çupra · levrek · ahtapot · taze karides. Sade pişirilir, limon ve zeytinyağıyla servis edilir.

> Bu akşam bir masa rezerve et.   *(NOT "Hemen rezervasyon yap!" — no exclamation, no marketing-speak.)*

**Avoid:**
- "Eşsiz lezzet deneyimi" / "gastronomik yolculuk" — these clichés don't fit.
- Exclamation marks anywhere.
- All-caps in body copy.
- Emoji.
- The words *premium, lüks, deluxe, exclusive*.

---

## VISUAL FOUNDATIONS

### Color

The brand is **mostly cobalt, white, and cream**. Orange is a single mark per screen — this is a seafood restaurant, not a juice shop.

| Token | Hex | Use |
|---|---|---|
| `--seyfi-blue` | `#16489f` | **Primary.** Hero panels, footer, all signage-style sections. The most important brand asset. |
| `--seyfi-blue-deep` | `#0e2f6e` | Pressed state for blue surfaces, deepest section bg. |
| `--seyfi-blue-ink` | `#0a1f4a` | Ink color for type on cream/white. |
| `--seyfi-white` | `#ffffff` | **Primary surface (alt to cobalt).** The plate-and-tablecloth color — clean food sections, body text on cobalt, photo frames. |
| `--seyfi-cream` | `#f4ede0` | **Secondary warm surface** — menu pages, cards on cobalt, receipt-style panels. Paired with white, never replacing it. |
| `--seyfi-paper` | `#fbf8f1` | Optional warmer body bg, between cream and white. |
| `--seyfi-orange` | `#e85a1e` | **Spark — use very sparingly.** One mark per screen, max. Handwritten "Seyfi" signature, single primary CTA, daily-special script tags. Never as a background. Never on body text. |
| `--seyfi-orange-soft` | `#f3b069` | Even more rarely — only for eyebrow labels on cobalt where vermillion would be too hot. |

**Rules.**
- The page is **either** cream/white-light **or** cobalt-dark. Never both adjacent — separate sections with full-bleed color blocks.
- **Orange appears no more than once per screen**, and only on a small surface (script signature, single tag, single CTA fill). The site reads cobalt-on-white; orange is the punctuation, not a color of the brand.
- White and cream coexist freely — use white for "clean food" surfaces (dish photos, menu sheets), cream for "warm document" surfaces (cards, receipts, signage panels on cobalt).
- Don't tint photos. Photography keeps its natural warm/golden cast.

### Type

| Family | Weight | Used for |
|---|---|---|
| **Cherston** (Larin Type Co — **paid**, user-supplied) | 700–900 | All display headlines, "BALIK" wordmark, menu category headers. Sharp-cornered uppercase display sans. Drop `Cherston-Bold.woff2` into `fonts/` to activate. |
| **Big Shoulders Display** (Google Fonts) | 700–900 | **Fallback** for Cherston — the closest free match (signage display sans). Used until Cherston is supplied. |
| **DM Sans** (Google Fonts) | 400–500 | All body, lead paragraphs, buttons, labels. |
| **Caveat** (Google Fonts) | 700 | Reserved for handwritten signature accents — "taze" stamps, daily-special tags, the "Seyfi" mark. Use 2–3x per page max. |

Tracking conventions:
- Display (Cherston): `0` to `+0.005em`. Don't tighten — the font is designed at its native spacing.
- Eyebrow / all-caps labels: `+0.18em` (wide, gives signage feel)
- Body: `0` (DM Sans is already balanced)

Sizes use a fluid `clamp()` scale from `--fs-micro` (12px) to `--fs-mega` (up to 144px). See `colors_and_type.css`.

> **Font substitution flag.** Cherston is a **paid** font from Larin Type Co — the file isn't bundled. Drop the .woff2/.otf files into `fonts/` (filenames: `Cherston-Bold.woff2`, `Cherston-Regular.woff2`) and the @font-face block at the top of `colors_and_type.css` will pick them up. Until then, **Big Shoulders Display** renders as the visual fallback. DM Sans and Caveat are Google Fonts and load automatically.

### Spacing

8-pt grid: 4, 8, 12, 16, 24, 32, 48, 64, 96, 128 — tokens `--s-1` through `--s-10`. Sections breathe — outer paddings on hero / signage panels are `--s-9` or `--s-10`. Cards inside are `--s-5` to `--s-6`.

### Backgrounds

- **Cobalt panels** are full-bleed flat color. They optionally have a **tiled creature pattern** at ~6–10% white opacity, large scale (creatures are big — 220–320 px across — not small repeating icons). The pattern is decoration; never compete with text.
- **Cream/paper panels** are flat. Optionally a single creature illustration sits as a **large faded ornament** in one corner.
- No gradients anywhere. No noise/grain overlays. No drop-shadows on the brand color blocks.
- Photography is full-bleed in editorial sections; in card layouts it's contained in a sharp-cornered or 2 px-radius frame.

### Animation & motion

- **Easing**: `cubic-bezier(0.22, 1, 0.36, 1)` — a soft "out" curve, like a wave settling. Tokenized as `--ease-out`.
- **Durations**: 140 / 260 / 480 ms (`--dur-fast/med/slow`). Default is `--dur-med`.
- **Allowed motion**: fade-in on scroll (16 px translate-y, 480 ms); button color/state change (140 ms); hover lifts of `translateY(-2px)` on cards; nothing else.
- **No** bouncy springs, no scale-in, no rotation, no parallax. The brand sits still and lets the food move.

### Hover / press states

- **Buttons (primary, on blue)** — hover: background lightens 6% (or a 1 px white outline appears). Active: shifts down 1 px, color deepens to `--seyfi-blue-deep`. Never opacity changes.
- **Buttons (primary, on cream)** — hover: background fills with `--seyfi-blue`, text turns white. Active: bg shifts to `--seyfi-blue-deep`.
- **Links inline** — underline `text-underline-offset: 4px`, decoration thickness 1.5 px. Hover: color → `--seyfi-orange`, underline color stays blue (creates a two-tone link).
- **Cards** — hover lifts `translateY(-2px)`, hairline rule deepens from 12% to 24% opacity. No scale.
- **Photo tiles** — hover: a thin 1.5 px cobalt frame appears inside (4 px inset). No zoom, no overlay.

### Borders & rules

- **Hairline**: 1 px, color `rgba(10,31,74,0.12)` (`--rule`). Used to divide menu rows.
- **Ink border**: 1.5 px solid `--seyfi-blue-ink`. Used on outlined buttons on cream.
- **Inverted hairline**: 1 px, `rgba(255,255,255,0.18)`. Dividers on cobalt.
- Borders are always single, never doubled. No "dashed" borders.

### Shadows

Soft, paper-like:
- `--shadow-1` (`0 1px 2px rgba(10,31,74,0.06)`) — inputs, default.
- `--shadow-2` (`0 6px 24px -8px rgba(10,31,74,0.18)`) — elevated card.
- `--shadow-3` (`0 24px 60px -24px rgba(10,31,74,0.30)`) — modal, the only "lifted" element on the page.

Cobalt panels **do not** carry shadow. They sit flat on the page. Cream cards on cobalt either use `--shadow-2` or a 1 px white hairline — not both.

### Corner radius

- **`0`** is the default. The brand reads as printed signage; sharp corners reinforce that.
- **`2 px`** on form inputs and small chips.
- **`4 px`** on buttons (a slight friendliness).
- **`999 px`** (pill) only on tag chips like *GÜNÜN MENÜSÜ*.
- Cards: `0`. Photos: `0` editorial, `2 px` if in a grid.

### Transparency & blur

- **Sticky header** on cobalt sections: `rgba(22, 72, 159, 0.85)` + `backdrop-filter: blur(12px) saturate(140%)`.
- Dish-detail modal scrim: `rgba(10, 31, 74, 0.6)`.
- That's it. No frosted-glass cards, no glassmorphism in the body of pages.

### Layout

- Max content width **1280 px**. Marketing hero allowed to go full-bleed.
- Outer page gutter: **24 px** mobile, **48 px** tablet, **80 px** desktop.
- Sections separated by **128 px** vertical on desktop, **64 px** on mobile.
- Grid: 12 columns desktop, 6 columns tablet, 4 columns mobile, 24 px gutters.
- **Fixed elements**: the header (top, blurred-cobalt), the reservation CTA on mobile (bottom, full-width orange).

### Photography direction

| Quality | Yes | No |
|---|---|---|
| Light | Bright, sunlit, golden hour | Studio strobe, flat |
| Hue | Warm, slight cool blue accents from sea/linen | Magenta, teal, neon |
| Subject | Fish whole or filleted, plates with linen + parsley + lemon, hands plating, sea bokeh | Pre-staged "perfect" plates, plastic garnishes |
| Color treatment | Untouched — keep natural saturation | B&W, heavy grain, vintage filter |
| Composition | Top-down or low 3/4. Negative space welcome. | Center-tight, gridded thumbnails |

---

## ICONOGRAPHY

**The Seyfi brand does not use a generic icon set.** No Lucide, no Heroicons, no Material Symbols on marketing surfaces. The visual language is carried entirely by the five hand-drawn **engraved sea creatures**:

| File | Subject | Use |
|---|---|---|
| `assets/icons/octopus.png` | Ahtapot | Hero ornament, "About" page mark, large-scale background. |
| `assets/icons/fish.png` | Balık (sea bass / levrek) | The flagship — menu category header, hero, header. |
| `assets/icons/crab.png` | Yengeç | "Mezeler" section ornament, footer mark. |
| `assets/icons/lobster.png` | Istakoz | "Özel menü" callout, premium dish badge. |
| `assets/icons/shrimp.png` | Karides | Menu category, decorative tile. |

All five are **white on transparent** at source. To use them:

```html
<img src="assets/icons/octopus.png" alt="" class="seyfi-creature">
```

They render correctly only on the **cobalt** or **deep blue** backgrounds. On cream, recolor them by applying a CSS filter (`filter: brightness(0) saturate(100%) invert(20%) sepia(80%) saturate(2000%) hue-rotate(210deg)` — gives ink-blue) or use the original navy PNGs in `source_images/`.

**Tile pattern.** The signature decorative use is a low-density scatter at large scale on cobalt panels. See `preview/Pattern-Creature-Tile.html` and `ui_kits/website/components/CreatureBg.jsx`. Density: ~1 creature per 280 × 280 px tile, rotated slightly, opacity 6–10%.

**Utility icons (UI controls).** For functional elements that *do* need an icon — close button, hamburger, arrow, phone, location, clock — use **Lucide** at 1.5 px stroke, via the CDN: `<script src="https://unpkg.com/lucide@latest"></script>`. This is a substitution; Seyfi has no original UI-icon set. Flag to user before shipping if a custom set is desired.

**Emoji & unicode.** Not used. Anywhere.

---

## Index

- [`colors_and_type.css`](./colors_and_type.css) — design tokens
- [`assets/`](./assets/) — icons, photos
- [`preview/`](./preview/) — design-system cards (rendered in the Design System tab)
- [`ui_kits/website/`](./ui_kits/website/) — Seyfi.com.tr UI kit + clickable demo
- [`SKILL.md`](./SKILL.md) — skill manifest, compatible with Claude Code Agent Skills

---

## Caveats & open questions

- **Two lockups in play.** The **heritage badge** (`assets/logos/seyfi-badge-heritage.jpg`) is the existing round Seyfi Balık Restoranı logo and should stay on stickers, tabela and physical signage where customers already recognize it. The **new wordmark** (orange *Seyfi* script → fish → **BALIK**, see `ui_kits/website/components/Wordmark.jsx`) is the primary digital lockup — header, footer, hero. Don't mix the two in a single composition.
- No official fonts were provided. **Cherston** is a paid font from Larin Type Co; drop `Cherston-Bold.woff2` into `fonts/` to activate. Until then **Big Shoulders Display** (Google) renders as the fallback. Montserrat and Caveat load automatically.
- All copy is **placeholder Turkish**, written in the brand's tone but not verified against the restaurant's actual offerings.
- The engraved creatures are **AI-generated**; they're high-quality but if commercial use is licence-sensitive, commission a real engraver.
